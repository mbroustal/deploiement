# deploiement
***

## Project
Ce projet n'a pas d'autre intérêt que de me permettre de suivre le TP. 

Les fonctions qu'il contient ne sont pas vraiment utiles dans la vraie vie. 

## Technologies
Ce projet est codé en python3.6 . Il n'utilise pour l'instant aucun package particulier.

## Fonctionnalités
Ce projet contient plusieurs fonctions à objectifs peu utiles:
* *hello* retourne "Hello, World!"
* *add_2* ajoute 2 à un entier n
* *is_even* indique si un entier est pair.

## Installation
To use this project, install it locally:


``
$ cd ../useless
$ git clone https://github.com/mbroustal/deploiement
``

## Collaboration
Ce projet est ouvert à tout contributeur. 

Fonctions à ajouter:
* *add_wow* ajoute un point d'exclamation à un string
* *error* retourne "ERROR" quelque soit la donnée d'entrée.

